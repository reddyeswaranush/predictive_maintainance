from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

from frontend.utils import format_table, chart_layout


def render_fleet_explorer(machine_view: pd.DataFrame) -> None:
    if machine_view.empty:
        st.info("No machines match the active filters.")
        return
    summary, table = st.tabs(["Fleet map", "Machine register"])
    with summary:
        left, right = st.columns([1, 1.35], gap="large")
        with left:
            status_counts = machine_view.get("status", pd.Series(dtype=str)).fillna("Unspecified").value_counts().rename_axis("Status").reset_index(name="Machines")
            figure = px.pie(status_counts, names="Status", values="Machines", hole=0.65, color="Status", color_discrete_sequence=["#65cf98", "#ffc46b", "#ff747d", "#70a7ff", "#bca5ff"])
            figure.update_layout(**chart_layout(370), showlegend=True)
            st.plotly_chart(figure, use_container_width=True, config={"displayModeBar": False})
        with right:
            location_counts = machine_view.get("location", pd.Series(dtype=str)).fillna("Unassigned").value_counts().rename_axis("Location").reset_index(name="Machines")
            figure = px.bar(location_counts, x="Location", y="Machines", color="Machines", color_continuous_scale=["#203a63", "#70a7ff"], text="Machines")
            figure.update_layout(**chart_layout(370), coloraxis_showscale=False)
            st.plotly_chart(figure, use_container_width=True, config={"displayModeBar": False})
    with table:
        export = machine_view.copy()
        export["failure_probability_display"] = export["failure_probability_display"].map("{:.1%}".format)
        export["temperature"] = export["temperature"].map("{:.1f}".format)
        st.dataframe(format_table(export, ["machine_id", "machine_name", "department", "location", "status", "condition", "temperature", "health_score_display", "failure_probability_display", "predicted_days"]), use_container_width=True, hide_index=True)
        st.download_button("Download filtered fleet CSV", machine_view.to_csv(index=False).encode("utf-8"), "factoryops_fleet.csv", "text/csv")

        with st.expander("Update a machine status"):
            options = machine_view["machine_id"].tolist()
            selected_id = st.selectbox("Machine", options, format_func=lambda identifier: f"#{identifier} · {machine_view.loc[machine_view['machine_id'].eq(identifier), 'machine_name'].iloc[0]}", key="machine_status_select")
            selected = machine_view[machine_view["machine_id"].eq(selected_id)].iloc[0]
            with st.form("update_machine_status"):
                new_status = st.selectbox("Operating status", ["Running", "Idle", "Maintenance", "Stopped"], index=["Running", "Idle", "Maintenance", "Stopped"].index(selected.get("status", "Running")) if selected.get("status", "Running") in ["Running", "Idle", "Maintenance", "Stopped"] else 0)
                if st.form_submit_button("Save status"):
                    payload = {key: selected.get(key) for key in ["machine_name", "department", "location"]}
                    payload["status"] = new_status
                    from frontend.app import send_record
                    ok, message = send_record("PUT", "machines", payload, int(selected_id))
                    (st.success if ok else st.error)(message)
