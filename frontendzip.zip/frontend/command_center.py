from typing import Any

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from frontend.utils import render_metric_card, number_column, state_badge, format_table, latest_telemetry, chart_layout


def render_command_center(machine_view: pd.DataFrame, telemetry: pd.DataFrame, incidents: pd.DataFrame, maintenance: pd.DataFrame) -> None:
    st.markdown("#### Real-time operational picture")
    total = len(machine_view)
    running = int(machine_view.get("status", pd.Series(dtype=str)).astype(str).str.lower().eq("running").sum()) if not machine_view.empty else 0
    critical = int(machine_view.get("condition", pd.Series(dtype=str)).eq("critical").sum()) if not machine_view.empty else 0
    warning = int(machine_view.get("condition", pd.Series(dtype=str)).eq("warning").sum()) if not machine_view.empty else 0
    average_health = number_column(machine_view, "health_score_display").replace(0, pd.NA).mean() if not machine_view.empty else 0
    average_health = 0 if pd.isna(average_health) else average_health

    metrics = st.columns(5)
    with metrics[0]:
        render_metric_card("Fleet availability", f"{running}/{total}", "Machines currently marked running")
    with metrics[1]:
        render_metric_card("Average health", f"{average_health:.0f}%", "Latest reported health score")
    with metrics[2]:
        render_metric_card("Critical attention", str(critical), "High-risk or overheating assets")
    with metrics[3]:
        render_metric_card("Watch list", str(warning), "Assets outside normal thresholds")
    with metrics[4]:
        open_incidents = int(incidents.get("status", pd.Series(dtype=str)).astype(str).str.lower().isin(["open", "in progress"]).sum()) if not incidents.empty else 0
        render_metric_card("Open incidents", str(open_incidents), "Open and in-progress incident records")

    left, right = st.columns([1.35, 1], gap="large")
    with left:
        st.markdown("#### Condition by machine")
        display = machine_view.sort_values(["condition", "failure_probability_display"], ascending=[True, False]).head(12) if not machine_view.empty else pd.DataFrame()
        for start in range(0, len(display), 3):
            columns = st.columns(3)
            for column, (_, machine) in zip(columns, display.iloc[start:start + 3].iterrows()):
                with column:
                    condition = str(machine.get("condition", "normal"))
                    st.markdown(
                        f'''<div class="machine-card {condition}"><h4>{machine.get("machine_name", "Unnamed machine")}</h4>
                        <p>{machine.get("location", "Unassigned location")} · {machine.get("department", "Unassigned department")}</p>
                        {state_badge(condition)} {state_badge(machine.get("status", "unknown"))}
                        <div style="margin-top:.8rem" class="metric-label">Temperature / risk</div>
                        <b>{float(machine.get("temperature", 0)):.1f}°C</b> <span class="subtle">· {float(machine.get("failure_probability_display", 0)):.0%}</span></div>''',
                        unsafe_allow_html=True,
                    )
    with right:
        st.markdown("#### Risk radar")
        if machine_view.empty:
            st.info("Add machines and telemetry to populate the risk radar.")
        else:
            chart_data = machine_view.sort_values("failure_probability_display", ascending=False).head(10)
            condition_colours = {"normal": "#65cf98", "warning": "#ffc46b", "critical": "#ff747d"}
            figure = go.Figure(
                go.Bar(
                    x=chart_data["failure_probability_display"],
                    y=chart_data["machine_name"],
                    orientation="h",
                    marker_color=[condition_colours.get(condition, "#70a7ff") for condition in chart_data["condition"]],
                    text=[f"{probability:.0%} · {condition.title()}" for probability, condition in zip(chart_data["failure_probability_display"], chart_data["condition"])],
                    textposition="outside",
                    cliponaxis=False,
                    hovertemplate="<b>%{y}</b><br>Failure probability: %{x:.1%}<extra></extra>",
                )
            )
            radar_layout = chart_layout(height=max(390, 44 * len(chart_data)))
            radar_layout.update(
                showlegend=False,
                margin={"l": 150, "r": 95, "t": 16, "b": 45},
                yaxis={"categoryorder": "total ascending", "title": None, "automargin": True},
                xaxis={"title": "Failure probability", "tickformat": ".0%", "range": [0, max(0.1, float(chart_data["failure_probability_display"].max()) + 0.15)]},
            )
            figure.update_layout(**radar_layout)
            st.plotly_chart(figure, use_container_width=True, config={"displayModeBar": False})

    st.markdown("#### Decision queue")
    queue_left, queue_right = st.columns(2, gap="large")
    with queue_left:
        st.caption("Highest-risk machines")
        columns = ["machine_name", "location", "temperature", "health_score_display", "failure_probability_display", "condition"]
        risk_table = format_table(machine_view.sort_values("failure_probability_display", ascending=False).head(8), columns).copy() if not machine_view.empty else pd.DataFrame()
        if "failure_probability_display" in risk_table:
            risk_table["failure_probability_display"] = risk_table["failure_probability_display"].map("{:.1%}".format)
        if "temperature" in risk_table:
            risk_table["temperature"] = risk_table["temperature"].map("{:.1f} °C".format)
        st.dataframe(risk_table, use_container_width=True, hide_index=True)
    with queue_right:
        st.caption("Maintenance workload")
        if maintenance.empty:
            st.info("No maintenance records available.")
        else:
            workload = maintenance.copy()
            if "status" in workload:
                workload = workload[~workload["status"].astype(str).str.lower().isin(["completed", "closed"]) ]
            st.dataframe(format_table(workload, ["id", "machine_id", "maintenance_type", "technician", "status", "cost"]), use_container_width=True, hide_index=True)

    if not telemetry.empty:
        st.markdown("#### Fleet signal snapshot")
        snapshot = latest_telemetry(telemetry)
        columns = [column for column in ["temperature", "vibration", "power", "rpm"] if column in snapshot]
        if columns:
            summary = snapshot[columns].mean(numeric_only=True).rename("Average").to_frame()
            st.dataframe(summary, use_container_width=True)
