from typing import Any

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from frontend.utils import number_column, latest_telemetry, format_table


def render_telemetry_lab(telemetry: pd.DataFrame, machines: pd.DataFrame) -> None:
    if telemetry.empty:
        st.info("No telemetry exists yet. Use Data Management to record a reading.")
        return
    machine_names = machines[["machine_id", "machine_name"]] if not machines.empty and {"machine_id", "machine_name"}.issubset(machines.columns) else pd.DataFrame(columns=["machine_id", "machine_name"])
    data = telemetry.merge(machine_names, on="machine_id", how="left")
    data["machine_label"] = data["machine_name"].fillna("Unknown machine #" + data["machine_id"].astype(str))
    selected_machine = st.selectbox("Inspect machine", sorted(data["machine_id"].dropna().unique()), format_func=lambda identifier: data.loc[data["machine_id"].eq(identifier), "machine_label"].iloc[0])
    selected = data[data["machine_id"].eq(selected_machine)].sort_values("id") if "id" in data else data[data["machine_id"].eq(selected_machine)]
    latest = selected.iloc[-1]
    metrics = st.columns(5)
    for column, label, suffix in [("temperature", "Temperature", "°C"), ("vibration", "Vibration", ""), ("rpm", "RPM", ""), ("power", "Power", ""), ("oil_level", "Oil level", "%")]:
        with metrics[["temperature", "vibration", "rpm", "power", "oil_level"].index(column)]:
            st.metric(label, f"{float(latest.get(column, 0)):.1f}{suffix}")

    signal_columns = [column for column in ["temperature", "pressure", "vibration", "voltage", "current", "power", "rpm", "humidity", "oil_level"] if column in selected]
    chosen_signals = st.multiselect("Signals", signal_columns, default=signal_columns[:3])
    if chosen_signals:
        figure = go.Figure()
        x_values = selected["id"] if "id" in selected else selected.index
        for signal in chosen_signals:
            figure.add_trace(go.Scatter(x=x_values, y=number_column(selected, signal), mode="lines+markers", name=signal.replace("_", " ").title()))
        from frontend.utils import chart_layout
        figure.update_layout(**chart_layout(430), xaxis_title="Telemetry record ID", yaxis_title="Recorded value")
        st.plotly_chart(figure, use_container_width=True, config={"displayModeBar": False})
        st.caption("The backend does not yet store timestamps; record ID is used as the sequence indicator.")

    st.markdown("#### Recent raw readings")
    st.dataframe(format_table(selected.sort_values("id", ascending=False), ["id", "machine_id", *signal_columns, "health_score", "failure_probability"]), use_container_width=True, hide_index=True)
    st.download_button("Download inspected telemetry CSV", selected.to_csv(index=False).encode("utf-8"), "telemetry_export.csv", "text/csv")
