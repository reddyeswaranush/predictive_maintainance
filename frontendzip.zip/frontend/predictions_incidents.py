from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

from frontend.utils import number_column, format_table, state_badge


def render_prediction_incident_page(predictions: pd.DataFrame, incidents: pd.DataFrame, machines: pd.DataFrame) -> None:
    machine_names = machines[["machine_id", "machine_name", "location"]] if not machines.empty else pd.DataFrame(columns=["machine_id", "machine_name", "location"])
    tab_predictions, tab_incidents = st.tabs(["Failure prediction prioritization", "Incident command board"])
    with tab_predictions:
        if predictions.empty:
            st.info("No predictions have been recorded.")
        else:
            view = predictions.merge(machine_names, on="machine_id", how="left").copy()
            view["failure_probability"] = number_column(view, "failure_probability")
            view["health_score"] = number_column(view, "health_score")
            view["priority"] = view["failure_probability"].map(lambda v: "critical" if v>=0.6 else ("warning" if v>=0.3 else "normal"))
            left, right = st.columns([1.15, 1], gap="large")
            with left:
                figure = px.scatter(view, x="health_score", y="failure_probability", size="failure_probability", color="priority", hover_name="machine_name", hover_data=["predicted_days", "location"], color_discrete_map={"normal": "#65cf98", "warning": "#ffc46b", "critical": "#ff747d"}, labels={"health_score": "Health score", "failure_probability": "Failure probability"})
                from frontend.utils import chart_layout
                figure.update_layout(**chart_layout(410), yaxis_tickformat=".0%")
                st.plotly_chart(figure, use_container_width=True, config={"displayModeBar": False})
            with right:
                st.markdown("#### Immediate attention")
                urgent = view.sort_values(["failure_probability", "predicted_days"], ascending=[False, True]).head(8).copy()
                urgent["failure_probability"] = urgent["failure_probability"].map("{:.1%}".format)
                st.dataframe(format_table(urgent, ["machine_name", "location", "failure_probability", "health_score", "predicted_days", "priority"]), use_container_width=True, hide_index=True)
            st.download_button("Download prediction CSV", view.to_csv(index=False).encode("utf-8"), "prediction_priorities.csv", "text/csv")
    with tab_incidents:
        if incidents.empty:
            st.info("No incidents have been recorded.")
        else:
            view = incidents.merge(machine_names, on="machine_id", how="left")
            status_order = ["Open", "In Progress", "Resolved", "Closed"]
            columns = st.columns(4)
            for column, status in zip(columns, status_order):
                with column:
                    st.markdown(f"##### {status}")
                    cards = view[view.get("status", pd.Series(dtype=str)).astype(str).str.lower().eq(status.lower())]
                    if cards.empty:
                        st.caption("No records")
                    for _, incident in cards.iterrows():
                        priority = str(incident.get("priority", "normal")).lower()
                        css = "critical" if priority == "critical" else "warning" if priority in {"high", "medium"} else "normal"
                        machine_label = incident.get("machine_name") or f"Machine #{incident.get('machine_id')}"
                        st.markdown(f'<div class="machine-card {css}"><b>{machine_label}</b><p>{incident.get("description", "No description")}</p>{state_badge(incident.get("priority", "normal"))}<br><span class="subtle">Owner: {incident.get("assigned_to", "Unassigned")}</span></div>', unsafe_allow_html=True)
